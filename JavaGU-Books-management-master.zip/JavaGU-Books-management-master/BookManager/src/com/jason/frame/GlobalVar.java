package com.jason.frame;

//com.jason.frame.GlobalVar.java
public class GlobalVar{
	public static String login_user;
} 